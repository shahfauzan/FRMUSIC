package com.offline.player

import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

class Th(val name: String, val top: Color, val bottom: Color, val accent: Color)

val themes = listOf(
    Th("Ocean", Color(0xFF0B1F3A), Color(0xFF1B4F72), Color(0xFF5DADE2)),
    Th("Sunset", Color(0xFF2D1B3D), Color(0xFF8E3B46), Color(0xFFFFA45B)),
    Th("Forest", Color(0xFF0E2A24), Color(0xFF1F5F4A), Color(0xFF58D68D)),
    Th("Berry", Color(0xFF2A0F3D), Color(0xFF6C2A7A), Color(0xFFE58BFF)),
    Th("Midnight", Color(0xFF07070C), Color(0xFF1C1C2B), Color(0xFF8C9EFF))
)
val speeds = listOf(0.75f, 1f, 1.25f, 1.5f, 2f)
val sorts = listOf("Title", "Artist", "Newest")

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { PlayerApp() }
    }
}

fun fmt(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    return "%d:%02d".format(s / 60, s % 60)
}

fun Modifier.glass(r: Dp = 20.dp): Modifier {
    val s = RoundedCornerShape(r)
    return clip(s)
        .background(Brush.verticalGradient(listOf(Color.White.copy(.20f), Color.White.copy(.07f))))
        .border(1.dp, Color.White.copy(.22f), s)
}

@Composable
fun Art(model: Any?, seed: String, size: Dp, radius: Dp = 12.dp) {
    val hue = seed.hashCode().mod(360).toFloat()
    Box(
        Modifier.size(size).clip(RoundedCornerShape(radius)).background(Color.hsv(hue, .55f, .75f)),
        contentAlignment = Alignment.Center
    ) {
        Text(seed.take(1).uppercase(), color = Color.White, fontWeight = FontWeight.Bold)
        AsyncImage(model, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
    }
}

@Composable
fun Chip(t: String, on: () -> Unit) {
    Text(t, Modifier.glass(50.dp).clickable { on() }.padding(horizontal = 16.dp, vertical = 9.dp), fontSize = 13.sp)
}

@Composable
fun SettingRow(title: String, value: String, on: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().glass().clickable { on() }.padding(16.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) { Text(title, fontWeight = FontWeight.SemiBold); Text(value) }
}

@Composable
fun PlayerApp() {
    val ctx = LocalContext.current
    val p = remember { ctx.getSharedPreferences("fr", Context.MODE_PRIVATE) }
    var themeIdx by remember { mutableIntStateOf(p.getInt("theme", 0)) }
    var sortIdx by remember { mutableIntStateOf(p.getInt("sort", 0)) }
    var speedIdx by remember { mutableIntStateOf(p.getInt("speed", 1)) }
    var blurBg by remember { mutableStateOf(p.getBoolean("blur", true)) }
    var favs by remember {
        mutableStateOf((p.getStringSet("favs", emptySet()) ?: emptySet()).mapNotNull { it.toLongOrNull() }.toSet())
    }
    var songs by remember { mutableStateOf<List<Song>>(emptyList()) }
    var granted by remember { mutableStateOf(false) }
    var controller by remember { mutableStateOf<MediaController?>(null) }
    var current by remember { mutableStateOf<MediaItem?>(null) }
    var playing by remember { mutableStateOf(false) }
    var shuffle by remember { mutableStateOf(false) }
    var repeat by remember { mutableIntStateOf(Player.REPEAT_MODE_OFF) }
    var showNow by remember { mutableStateOf(false) }
    var tab by remember { mutableIntStateOf(0) }
    var query by remember { mutableStateOf("") }
    var pos by remember { mutableLongStateOf(0L) }
    var dur by remember { mutableLongStateOf(0L) }
    var sleepEnd by remember { mutableLongStateOf(0L) }
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var showSleep by remember { mutableStateOf(false) }

    val perms = if (Build.VERSION.SDK_INT >= 33)
        arrayOf(Manifest.permission.READ_MEDIA_AUDIO, Manifest.permission.POST_NOTIFICATIONS)
    else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
    fun hasPerm() = ContextCompat.checkSelfPermission(ctx, perms[0]) == PackageManager.PERMISSION_GRANTED
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        granted = hasPerm()
        if (granted) songs = loadSongs(ctx)
    }
    LaunchedEffect(Unit) {
        if (hasPerm()) {
            granted = true
            songs = withContext(Dispatchers.IO) { loadSongs(ctx) }
        } else launcher.launch(perms)
    }
    DisposableEffect(Unit) {
        val future = MediaController.Builder(ctx, SessionToken(ctx, ComponentName(ctx, PlaybackService::class.java))).buildAsync()
        future.addListener({
            val c = future.get()
            controller = c
            fun sync(pl: Player) {
                current = pl.currentMediaItem; playing = pl.isPlaying
                shuffle = pl.shuffleModeEnabled; repeat = pl.repeatMode
            }
            c.addListener(object : Player.Listener {
                override fun onEvents(pl: Player, e: Player.Events) = sync(pl)
            })
            sync(c)
        }, ContextCompat.getMainExecutor(ctx))
        onDispose { MediaController.releaseFuture(future) }
    }
    LaunchedEffect(controller) {
        while (true) {
            controller?.let { pos = it.currentPosition; dur = it.duration.coerceAtLeast(0) }
            delay(500)
        }
    }
    LaunchedEffect(controller, speedIdx) { controller?.setPlaybackSpeed(speeds[speedIdx]) }
    LaunchedEffect(sleepEnd) {
        while (sleepEnd > System.currentTimeMillis()) { now = System.currentTimeMillis(); delay(1000) }
        if (sleepEnd > 0) { controller?.pause(); sleepEnd = 0 }
    }

    val th = themes[themeIdx]
    val shown = songs.filter {
        (tab != 1 || it.id in favs) &&
            (query.isBlank() || "${it.title} ${it.artist} ${it.album}".contains(query, ignoreCase = true))
    }.let { l ->
        when (sortIdx) { 1 -> l.sortedBy { it.artist.lowercase() }; 2 -> l.sortedByDescending { it.id }; else -> l }
    }
    fun playList(i: Int) {
        val c = controller ?: return
        c.setMediaItems(shown.map { it.toItem() }, i, 0)
        c.prepare(); c.play()
    }
    fun toggle() { controller?.let { if (it.isPlaying) it.pause() else it.play() } }
    fun toggleFav(id: Long) {
        favs = if (id in favs) favs - id else favs + id
        p.edit().putStringSet("favs", favs.map { it.toString() }.toSet()).apply()
    }
    val item = current
    val sleepLabel = if (sleepEnd > now) "Sleep " + fmt(sleepEnd - now) else "Sleep timer"

    BackHandler(showNow) { showNow = false }
    MaterialTheme(colorScheme = darkColorScheme(primary = th.accent)) {
        CompositionLocalProvider(LocalContentColor provides Color.White) {
            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(th.top, th.bottom)))) {
                if (blurBg && item != null)
                    AsyncImage(item.mediaMetadata.artworkUri, null, Modifier.fillMaxSize().blur(48.dp), alpha = .28f, contentScale = ContentScale.Crop)
                if (showNow && item != null) {
                    NowPlaying(
                        item, playing, pos, dur, shuffle, repeat, controller, th.accent,
                        item.mediaId.toLongOrNull() in favs, { item.mediaId.toLongOrNull()?.let { toggleFav(it) } },
                        sleepLabel, { showSleep = true }, "${speeds[speedIdx]}x",
                        { speedIdx = (speedIdx + 1) % speeds.size; p.edit().putInt("speed", speedIdx).apply() },
                        ::toggle
                    ) { showNow = false }
                } else Column(Modifier.fillMaxSize().padding(top = 18.dp)) {
                    Box(Modifier.weight(1f)) {
                        if (tab == 2) Column(
                            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp),
                            verticalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            Text("Settings", fontSize = 26.sp, fontWeight = FontWeight.Bold)
                            Column(Modifier.fillMaxWidth().glass().padding(16.dp)) {
                                Text("Theme", fontWeight = FontWeight.SemiBold)
                                Spacer(Modifier.height(10.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                    themes.forEachIndexed { i, t ->
                                        Box(
                                            Modifier.size(44.dp).clip(CircleShape)
                                                .background(Brush.verticalGradient(listOf(t.accent, t.bottom)))
                                                .then(if (i == themeIdx) Modifier.border(3.dp, Color.White, CircleShape) else Modifier)
                                                .clickable { themeIdx = i; p.edit().putInt("theme", i).apply() }
                                        )
                                    }
                                }
                                Spacer(Modifier.height(6.dp))
                                Text(th.name, fontSize = 12.sp)
                            }
                            SettingRow("Sort songs by", sorts[sortIdx]) { sortIdx = (sortIdx + 1) % 3; p.edit().putInt("sort", sortIdx).apply() }
                            SettingRow("Playback speed", "${speeds[speedIdx]}x") { speedIdx = (speedIdx + 1) % speeds.size; p.edit().putInt("speed", speedIdx).apply() }
                            Row(Modifier.fillMaxWidth().glass().padding(horizontal = 16.dp, vertical = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                Text("Blurred cover background", fontWeight = FontWeight.SemiBold)
                                Switch(blurBg, { blurBg = it; p.edit().putBoolean("blur", it).apply() })
                            }
                            SettingRow("Rescan music", "${songs.size} songs") { if (granted) songs = loadSongs(ctx) }
                            Text("FR Music Player 2.0", fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
                        } else Column(Modifier.fillMaxSize()) {
                            Text(if (tab == 0) "FR Music Player" else "Favorites", fontSize = 26.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 18.dp))
                            Text("${shown.size} songs", fontSize = 13.sp, modifier = Modifier.padding(horizontal = 18.dp))
                            OutlinedTextField(
                                query, { query = it }, singleLine = true, placeholder = { Text("Search title, artist or album") },
                                shape = RoundedCornerShape(16.dp),
                                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = th.accent, unfocusedBorderColor = Color.White.copy(.3f)),
                                modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 8.dp)
                            )
                            if (!granted) {
                                Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text("Allow access to your music so the app can find your songs.")
                                    Spacer(Modifier.height(12.dp))
                                    Button({ launcher.launch(perms) }) { Text("Allow music access") }
                                }
                            } else if (shown.isEmpty()) {
                                Text(if (tab == 1) "No favorites yet. Tap the heart on a song." else "No music found.", modifier = Modifier.padding(24.dp))
                            } else LazyColumn(Modifier.fillMaxSize()) {
                                itemsIndexed(shown, key = { _, s -> s.id }) { i, s ->
                                    val isCur = item?.mediaId == s.id.toString()
                                    Row(
                                        Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 4.dp).glass(16.dp)
                                            .clickable { playList(i) }.padding(8.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Art(s.art, s.title, 52.dp)
                                        Spacer(Modifier.width(12.dp))
                                        Column(Modifier.weight(1f)) {
                                            Text(s.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold,
                                                color = if (isCur) th.accent else Color.White)
                                            Text(s.artist + " · " + fmt(s.durationMs), maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 13.sp,
                                                color = Color.White.copy(.7f))
                                        }
                                        TextButton({ toggleFav(s.id) }) {
                                            Text(if (s.id in favs) "♥" else "♡", fontSize = 20.sp, color = if (s.id in favs) th.accent else Color.White.copy(.7f))
                                        }
                                    }
                                }
                            }
                        }
                    }
                    if (item != null) Row(
                        Modifier.fillMaxWidth().padding(horizontal = 12.dp).glass(20.dp).clickable { showNow = true }.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Art(item.mediaMetadata.artworkUri, item.mediaMetadata.title?.toString() ?: "", 44.dp)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(item.mediaMetadata.title?.toString() ?: "", maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
                            Text(item.mediaMetadata.artist?.toString() ?: "", maxLines = 1, fontSize = 13.sp)
                        }
                        TextButton(::toggle) { Text(if (playing) "❚❚" else "▶", fontSize = 20.sp, color = th.accent) }
                    }
                    Row(Modifier.fillMaxWidth().padding(12.dp).glass(24.dp).padding(4.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                        listOf("Songs", "Favorites", "Settings").forEachIndexed { i, n ->
                            TextButton({ tab = i }) {
                                Text(n, color = if (tab == i) th.accent else Color.White.copy(.7f), fontWeight = FontWeight.SemiBold)
                            }
                        }
                    }
                }
                if (showSleep) AlertDialog(
                    onDismissRequest = { showSleep = false }, confirmButton = {},
                    title = { Text("Sleep timer") },
                    text = {
                        Column {
                            listOf(15, 30, 45, 60).forEach { m ->
                                TextButton({ sleepEnd = System.currentTimeMillis() + m * 60000L; now = System.currentTimeMillis(); showSleep = false }) { Text("$m minutes") }
                            }
                            TextButton({ sleepEnd = 0; showSleep = false }) { Text("Turn off timer") }
                        }
                    }
                )
            }
        }
    }
}

@Composable
fun NowPlaying(
    item: MediaItem, playing: Boolean, pos: Long, dur: Long, shuffle: Boolean, repeat: Int,
    c: MediaController?, accent: Color, fav: Boolean, onFav: () -> Unit,
    sleepLabel: String, onSleep: () -> Unit, speedLabel: String, onSpeed: () -> Unit,
    toggle: () -> Unit, onBack: () -> Unit
) {
    val title = item.mediaMetadata.title?.toString() ?: ""
    Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            TextButton(onBack) { Text("⌄ Back", color = Color.White) }
            TextButton(onFav) { Text(if (fav) "♥" else "♡", fontSize = 24.sp, color = if (fav) accent else Color.White) }
        }
        Box(Modifier.glass(28.dp).padding(8.dp)) { Art(item.mediaMetadata.artworkUri, title, 290.dp, 22.dp) }
        Spacer(Modifier.height(20.dp))
        Text(title, fontSize = 22.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(listOfNotNull(item.mediaMetadata.artist, item.mediaMetadata.albumTitle).joinToString(" · "), fontSize = 14.sp, maxLines = 1)
        Spacer(Modifier.height(8.dp))
        Slider(
            value = if (dur > 0) (pos.toFloat() / dur).coerceIn(0f, 1f) else 0f,
            onValueChange = { c?.seekTo((it * dur).toLong()) },
            colors = SliderDefaults.colors(thumbColor = accent, activeTrackColor = accent, inactiveTrackColor = Color.White.copy(.25f))
        )
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(fmt(pos), fontSize = 12.sp); Text(fmt(dur), fontSize = 12.sp)
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
            TextButton({ c?.shuffleModeEnabled = !shuffle }) { Text("🔀", fontSize = 22.sp, color = if (shuffle) accent else Color.Gray) }
            TextButton({ c?.seekToPrevious() }) { Text("⏮", fontSize = 26.sp, color = Color.White) }
            Button(toggle, Modifier.size(72.dp), shape = RoundedCornerShape(36.dp), contentPadding = PaddingValues(0.dp),
                colors = ButtonDefaults.buttonColors(containerColor = accent, contentColor = Color.Black)) {
                Text(if (playing) "❚❚" else "▶", fontSize = 26.sp)
            }
            TextButton({ c?.seekToNext() }) { Text("⏭", fontSize = 26.sp, color = Color.White) }
            TextButton({
                c?.repeatMode = when (repeat) {
                    Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                    Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                    else -> Player.REPEAT_MODE_OFF
                }
            }) { Text(if (repeat == Player.REPEAT_MODE_ONE) "🔂" else "🔁", fontSize = 22.sp, color = if (repeat != Player.REPEAT_MODE_OFF) accent else Color.Gray) }
        }
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) { Chip(sleepLabel, onSleep); Chip("Speed $speedLabel", onSpeed) }
    }
}
